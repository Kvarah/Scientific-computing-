# BIT 2118: Scientific Computing

Python implementations (NumPy, SciPy, Matplotlib) of the group work assignment tasks 2-20, plus a related real-world IT support case.

## Setup

```bash
pip install -r requirements.txt
python src/task02_numpy_arrays_and_numerical_computation.py
```

## Tasks

| Task | Topic | File |
|------|-------|------|
| 2 | Numpy Arrays And Numerical Computation | [`task02_numpy_arrays_and_numerical_computation.py`](src/task02_numpy_arrays_and_numerical_computation.py) |
| 3 | Mathematical Functions And Vectorization | [`task03_mathematical_functions_and_vectorization.py`](src/task03_mathematical_functions_and_vectorization.py) |
| 4 | Floating Point Arithmetic And Numerical Errors | [`task04_floating_point_arithmetic_and_numerical_errors.py`](src/task04_floating_point_arithmetic_and_numerical_errors.py) |
| 5 | Matrix Algebra And Matrix Operations | [`task05_matrix_algebra_and_matrix_operations.py`](src/task05_matrix_algebra_and_matrix_operations.py) |
| 6 | Solution Of Systems Of Linear Equations | [`task06_solution_of_systems_of_linear_equations.py`](src/task06_solution_of_systems_of_linear_equations.py) |
| 7 | Gaussian Elimination And Lu Decomposition | [`task07_gaussian_elimination_and_lu_decomposition.py`](src/task07_gaussian_elimination_and_lu_decomposition.py) |
| 8 | Iterative Methods For Linear Systems | [`task08_iterative_methods_for_linear_systems.py`](src/task08_iterative_methods_for_linear_systems.py) |
| 9 | Eigenvalues And Eigenvectors | [`task09_eigenvalues_and_eigenvectors.py`](src/task09_eigenvalues_and_eigenvectors.py) |
| 10 | Root Finding Bisection And Fixed Point Methods | [`task10_root_finding_bisection_and_fixed_point_methods.py`](src/task10_root_finding_bisection_and_fixed_point_methods.py) |
| 11 | Root Finding Newton Raphson And Secant Methods | [`task11_root_finding_newton_raphson_and_secant_methods.py`](src/task11_root_finding_newton_raphson_and_secant_methods.py) |
| 12 | Polynomial And Nonlinear Equation Solving | [`task12_polynomial_and_nonlinear_equation_solving.py`](src/task12_polynomial_and_nonlinear_equation_solving.py) |
| 13 | Interpolation | [`task13_interpolation.py`](src/task13_interpolation.py) |
| 14 | Curve Fitting And Approximation | [`task14_curve_fitting_and_approximation.py`](src/task14_curve_fitting_and_approximation.py) |
| 15 | Numerical Differentiation | [`task15_numerical_differentiation.py`](src/task15_numerical_differentiation.py) |
| 16 | Numerical Integration | [`task16_numerical_integration.py`](src/task16_numerical_integration.py) |
| 17 | Ordinary Differential Equations Euler Method | [`task17_ordinary_differential_equations_euler_method.py`](src/task17_ordinary_differential_equations_euler_method.py) |
| 18 | Numerical Solution Of Odes Using Scipy | [`task18_numerical_solution_of_odes_using_scipy.py`](src/task18_numerical_solution_of_odes_using_scipy.py) |
| 19 | Numerical Optimization | [`task19_numerical_optimization.py`](src/task19_numerical_optimization.py) |
| 20 | Random Numbers And Monte Carlo Methods | [`task20_random_numbers_and_monte_carlo_methods.py`](src/task20_random_numbers_and_monte_carlo_methods.py) |
| - | Real-world case: IT support response times | [`real_world_it_support_response_times.py`](src/real_world_it_support_response_times.py) |

## Author

Add your name and registration number here.
